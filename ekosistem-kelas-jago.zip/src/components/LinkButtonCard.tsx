import {
  ArrowUpRight,
  Check,
  Compass,
  Copy,
  Cpu,
  Film,
  Layers,
  Megaphone,
  ShoppingBag,
  Terminal,
} from 'lucide-react';
import type { EcosystemLink } from '../data/ecosystemLinks';

interface LinkButtonCardProps {
  item: EcosystemLink;
  isCopied: boolean;
  onCopy: (item: EcosystemLink) => void;
}

function CategoryIcon({ name }: { name: EcosystemLink['iconName'] }) {
  const iconClass = 'w-5 h-5 stroke-[1.75]';
  switch (name) {
    case 'terminal':
      return <Terminal className={iconClass} aria-hidden="true" />;
    case 'film':
      return <Film className={iconClass} aria-hidden="true" />;
    case 'shopping-bag':
      return <ShoppingBag className={iconClass} aria-hidden="true" />;
    case 'megaphone':
      return <Megaphone className={iconClass} aria-hidden="true" />;
    case 'layers':
      return <Layers className={iconClass} aria-hidden="true" />;
    case 'compass':
      return <Compass className={iconClass} aria-hidden="true" />;
    case 'cpu':
      return <Cpu className={iconClass} aria-hidden="true" />;
  }
}

export function LinkButtonCard({ item, isCopied, onCopy }: LinkButtonCardProps) {
  return (
    <div className="group relative flex items-stretch bg-white border border-neutral-200/90 rounded-2xl transition-[border-color,box-shadow,transform] duration-150 ease-[cubic-bezier(0.16,1,0.3,1)] hover:border-neutral-400 hover:shadow-[0_4px_20px_rgba(20,20,19,0.05)]">
      <a
        href={item.url}
        target="_blank"
        rel="noopener noreferrer"
        className="flex-1 min-w-0 min-h-[76px] flex items-center gap-3.5 sm:gap-4 p-4 sm:p-5 rounded-l-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-inset active:scale-[0.995] transition-transform duration-150"
      >
        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-neutral-100 text-neutral-800 group-hover:bg-neutral-950 group-hover:text-white transition-colors duration-150 flex items-center justify-center shrink-0">
          <CategoryIcon name={item.iconName} />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs text-neutral-500 mb-0.5">
            <span className="font-mono tabular-nums text-neutral-400">{item.index}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{item.categoryLabel}</span>
          </div>

          <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 min-w-0">
            <h2 className="font-display text-base sm:text-[17px] font-semibold tracking-tight text-neutral-950 truncate">
              {item.name}
            </h2>
            <span className="text-xs sm:text-sm font-medium text-blue-800 truncate">
              {item.subtitle}
            </span>
          </div>

          <p className="text-xs sm:text-sm text-neutral-600 line-clamp-2 sm:line-clamp-1 mt-1 leading-relaxed">
            {item.description}
          </p>
        </div>

        <div className="shrink-0 pl-1 flex items-center text-neutral-400 group-hover:text-neutral-950 transition-colors duration-150">
          <ArrowUpRight
            className="w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-150"
            aria-hidden="true"
          />
        </div>
      </a>

      <button
        type="button"
        onClick={() => onCopy(item)}
        aria-label={isCopied ? `Tautan ${item.name} tersalin` : `Salin tautan ${item.name}`}
        title={isCopied ? 'Tautan tersalin' : `Salin ${item.domain}`}
        className="w-12 sm:w-14 min-h-[44px] shrink-0 flex items-center justify-center border-l border-neutral-100 text-neutral-400 hover:text-neutral-950 hover:bg-neutral-50 active:scale-95 transition-[color,background-color,transform] duration-150 rounded-r-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-inset cursor-pointer"
      >
        {isCopied ? (
          <Check className="w-4 h-4 text-emerald-700" aria-hidden="true" />
        ) : (
          <Copy className="w-4 h-4" aria-hidden="true" />
        )}
      </button>
    </div>
  );
}
