export type EcosystemCategory = 'all' | 'ai' | 'business' | 'creative';

export interface EcosystemLink {
  id: string;
  index: string;
  name: string;
  subtitle: string;
  description: string;
  category: Exclude<EcosystemCategory, 'all'>;
  categoryLabel: string;
  domain: string;
  url: string;
  iconName: 'terminal' | 'film' | 'shopping-bag' | 'megaphone' | 'layers' | 'compass' | 'cpu';
}

export interface CategoryFilter {
  id: EcosystemCategory;
  label: string;
}

export const CATEGORY_FILTERS: CategoryFilter[] = [
  { id: 'all', label: 'Semua' },
  { id: 'ai', label: 'AI & Otomasi' },
  { id: 'business', label: 'Bisnis & Iklan' },
  { id: 'creative', label: 'Kreatif & Motion' },
];

export const ECOSYSTEM_LINKS: EcosystemLink[] = [
  {
    id: 'jagoclaude',
    index: '01',
    name: 'JagoClaude',
    subtitle: 'AI Coding & Workflow Bisnis',
    description: 'Panduan praktis memaksimalkan Claude untuk produktivitas, penulisan kode, dan otomasi kerja.',
    category: 'ai',
    categoryLabel: 'AI & Otomasi',
    domain: 'jagoclaude.com',
    url: 'https://jagoclaude.com',
    iconName: 'terminal',
  },
  {
    id: 'jagomotion',
    index: '02',
    name: 'JagoMotion',
    subtitle: 'Motion Graphics & Visual Dinamis',
    description: 'Kelas desain gerak dan animasi visual modern untuk kebutuhan konten, produk, dan brand.',
    category: 'creative',
    categoryLabel: 'Kreatif & Motion',
    domain: 'jagomotion.com',
    url: 'https://jagomotion.com',
    iconName: 'film',
  },
  {
    id: 'jagoshopee',
    index: '03',
    name: 'JagoShopee',
    subtitle: 'Optimasi Toko & Afiliasi',
    description: 'Strategi riset produk, optimasi etalase, dan peningkatan penjualan di ekosistem Shopee.',
    category: 'business',
    categoryLabel: 'Bisnis & Iklan',
    domain: 'jagoshopee.com',
    url: 'https://jagoshopee.com',
    iconName: 'shopping-bag',
  },
  {
    id: 'jagoiklan',
    index: '04',
    name: 'JagoIklan',
    subtitle: 'Performance Ads & Konversi',
    description: 'Kerangka kerja beriklan di Meta Ads dan TikTok Ads dari riset audiens hingga scale-up.',
    category: 'business',
    categoryLabel: 'Bisnis & Iklan',
    domain: 'jagoiklan.com',
    url: 'https://jagoiklan.com',
    iconName: 'megaphone',
  },
  {
    id: 'jagoscalev',
    index: '05',
    name: 'JagoScalev',
    subtitle: 'Landing Page & Funnel Penjualan',
    description: 'Bangun halaman penawaran, form checkout, dan manajemen pesanan otomatis dengan Scalev.',
    category: 'business',
    categoryLabel: 'Bisnis & Iklan',
    domain: 'jagoscalev.com',
    url: 'https://jagoscalev.com',
    iconName: 'layers',
  },
  {
    id: 'jagogrok',
    index: '06',
    name: 'JagoGrok',
    subtitle: 'Riset Real-Time & Konten Cepat',
    description: 'Eksplorasi teknik prompting, analisis tren cepat, dan produksi konten berbasis Grok.',
    category: 'ai',
    categoryLabel: 'AI & Otomasi',
    domain: 'jagogrok.com',
    url: 'https://jagogrok.com',
    iconName: 'compass',
  },
  {
    id: 'jagoai',
    index: '07',
    name: 'JagoAI',
    subtitle: 'Kelas Google AI Studio',
    description: 'Belajar merancang prototipe dan membangun aplikasi berbasis AI langsung di Google AI Studio.',
    category: 'ai',
    categoryLabel: 'AI & Otomasi',
    domain: 'jagoai.com',
    url: 'https://jagoai.com',
    iconName: 'cpu',
  },
];
