import { useMemo, useState } from 'react';
import { Check, Copy, Search, X } from 'lucide-react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import {
  CATEGORY_FILTERS,
  ECOSYSTEM_LINKS,
  type EcosystemCategory,
  type EcosystemLink,
} from './data/ecosystemLinks';
import { LinkButtonCard } from './components/LinkButtonCard';

const EMBLEM_IMAGE_PATH = '/src/assets/images/kelas_jago_emblem_1795673287057.jpg';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<EcosystemCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bioCopied, setBioCopied] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  const categoryCounts = useMemo(() => {
    const counts: Record<EcosystemCategory, number> = {
      all: ECOSYSTEM_LINKS.length,
      ai: 0,
      business: 0,
      creative: 0,
    };
    for (const item of ECOSYSTEM_LINKS) {
      counts[item.category] += 1;
    }
    return counts;
  }, []);

  const filteredLinks = useMemo(() => {
    const normalizedQuery = searchQuery.trim().toLowerCase();
    return ECOSYSTEM_LINKS.filter((item) => {
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      if (!matchesCategory) return false;
      if (!normalizedQuery) return true;
      return (
        item.name.toLowerCase().includes(normalizedQuery) ||
        item.subtitle.toLowerCase().includes(normalizedQuery) ||
        item.description.toLowerCase().includes(normalizedQuery) ||
        item.categoryLabel.toLowerCase().includes(normalizedQuery)
      );
    });
  }, [activeCategory, searchQuery]);

  const handleSelectCategory = (category: EcosystemCategory) => {
    setActiveCategory(category);
  };

  const handleCopyItem = async (item: EcosystemLink) => {
    try {
      await navigator.clipboard.writeText(item.url);
      setCopiedId(item.id);
      window.setTimeout(() => {
        setCopiedId((current) => (current === item.id ? null : current));
      }, 1800);
    } catch {
      // Ignore clipboard failures in restricted contexts
    }
  };

  const handleCopyBioLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setBioCopied(true);
      window.setTimeout(() => {
        setBioCopied(false);
      }, 1800);
    } catch {
      // Ignore clipboard failures in restricted contexts
    }
  };

  const handleNavClick = (category: EcosystemCategory) => {
    setActiveCategory(category);
    const section = document.getElementById('katalog-tautan');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <MotionConfig reducedMotion="user">
      <div id="top" className="min-h-screen flex flex-col bg-[#f7f7f5] text-neutral-950">
        <header className="sticky top-0 z-30 bg-[#f7f7f5]/90 backdrop-blur-md border-b border-neutral-200/80">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-8">
            <a
              href="#top"
              className="font-display text-base sm:text-lg font-bold tracking-tight text-neutral-950 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 rounded-md"
            >
              Kelas Jago
            </a>

            <nav
              aria-label="Navigasi kategori ekosistem"
              className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600"
            >
              <button
                type="button"
                onClick={() => handleNavClick('all')}
                className={`whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer hover:text-neutral-950 ${
                  activeCategory === 'all' ? 'text-neutral-950 underline underline-offset-4' : ''
                }`}
              >
                Semua Kelas
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('ai')}
                className={`whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer hover:text-neutral-950 ${
                  activeCategory === 'ai' ? 'text-neutral-950 underline underline-offset-4' : ''
                }`}
              >
                AI & Otomasi
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('business')}
                className={`whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer hover:text-neutral-950 ${
                  activeCategory === 'business'
                    ? 'text-neutral-950 underline underline-offset-4'
                    : ''
                }`}
              >
                Bisnis & Iklan
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('creative')}
                className={`whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer hover:text-neutral-950 ${
                  activeCategory === 'creative'
                    ? 'text-neutral-950 underline underline-offset-4'
                    : ''
                }`}
              >
                Kreatif
              </button>
            </nav>

            <div className="flex items-center shrink-0">
              <button
                type="button"
                onClick={handleCopyBioLink}
                className="inline-flex items-center justify-center gap-2 min-h-[40px] sm:min-h-[40px] px-4 py-2 text-xs sm:text-sm font-medium rounded-xl bg-neutral-950 text-white hover:bg-neutral-800 active:scale-[0.98] transition-[background-color,transform] duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2"
              >
                {bioCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                    <span>Tautan Tersalin</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Salin Link Bio</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            <aside className="lg:col-span-5 lg:sticky lg:top-24 space-y-6">
              <div className="flex items-center gap-4 lg:block lg:space-y-5">
                <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-2xl border border-neutral-200/90 bg-white overflow-hidden shrink-0 shadow-xs">
                  {!imageFailed ? (
                    <img
                      src={EMBLEM_IMAGE_PATH}
                      alt="Emblem Ekosistem Kelas Jago"
                      referrerPolicy="no-referrer"
                      onError={() => setImageFailed(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-neutral-900 to-neutral-700 text-white font-display text-2xl font-bold tracking-tight">
                      KJ
                    </div>
                  )}
                </div>

                <div className="min-w-0">
                  <p className="text-xs font-medium text-blue-800 mb-1">
                    Direktori Resmi Pembelajaran Digital
                  </p>
                  <h1 className="font-display text-[clamp(1.75rem,3.4vw,2.65rem)] font-bold tracking-tight leading-[1.12] text-neutral-950 text-balance">
                    Ekosistem Kelas Jago
                  </h1>
                </div>
              </div>

              <p className="text-sm sm:text-base text-neutral-600 leading-relaxed max-w-prose">
                Satu halaman ringkas untuk mengakses seluruh program belajar praktis di ekosistem
                Kelas Jago—mulai dari pemanfaatan AI, produksi visual, iklan berbayar, hingga
                sistem penjualan digital.
              </p>

              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-neutral-500 pt-1">
                <span className="tabular-nums font-medium text-neutral-700">
                  {ECOSYSTEM_LINKS.length} Program Aktif
                </span>
                <span aria-hidden="true">·</span>
                <span>Materi Praktis</span>
                <span aria-hidden="true">·</span>
                <span>Akses Langsung</span>
              </div>

              <div className="pt-2 border-t border-neutral-200/80">
                <label htmlFor="search-ecosystem" className="sr-only">
                  Cari kelas atau kategori
                </label>
                <div className="relative">
                  <Search
                    className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    id="search-ecosystem"
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari kelas, misal Google AI Studio..."
                    className="w-full min-h-[44px] pl-10 pr-10 py-2.5 text-sm bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-neutral-400 focus:outline-none focus:border-neutral-950 focus:ring-2 focus:ring-blue-700/15 transition-colors duration-150"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      aria-label="Hapus pencarian"
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-neutral-400 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" aria-hidden="true" />
                    </button>
                  )}
                </div>
              </div>
            </aside>

            <section
              id="katalog-tautan"
              aria-label="Daftar tautan ekosistem Kelas Jago"
              className="lg:col-span-7 space-y-5 scroll-mt-20"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div
                  role="tablist"
                  aria-label="Filter kategori kelas"
                  className="flex items-center gap-1 p-1 bg-neutral-200/70 rounded-xl overflow-x-auto"
                >
                  {CATEGORY_FILTERS.map((filter) => {
                    const isActive = activeCategory === filter.id;
                    return (
                      <button
                        key={filter.id}
                        role="tab"
                        aria-selected={isActive}
                        type="button"
                        onClick={() => handleSelectCategory(filter.id)}
                        className={`min-h-[40px] sm:min-h-[36px] px-3.5 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 ${
                          isActive
                            ? 'bg-white text-neutral-950 shadow-xs'
                            : 'text-neutral-600 hover:text-neutral-950'
                        }`}
                      >
                        {filter.label}{' '}
                        <span className="tabular-nums text-neutral-400 ml-0.5">
                          {categoryCounts[filter.id]}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <p className="text-xs text-neutral-500 tabular-nums shrink-0">
                  Menampilkan {filteredLinks.length} dari {ECOSYSTEM_LINKS.length} tautan
                </p>
              </div>

              {filteredLinks.length > 0 ? (
                <div className="space-y-3">
                  <AnimatePresence mode="popLayout" initial={false}>
                    {filteredLinks.map((item) => (
                      <motion.div
                        key={item.id}
                        layout="position"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                      >
                        <LinkButtonCard
                          item={item}
                          isCopied={copiedId === item.id}
                          onCopy={handleCopyItem}
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="bg-white border border-neutral-200/90 rounded-2xl p-8 text-center space-y-3">
                  <p className="font-display text-base font-semibold text-neutral-900">
                    Kelas tidak ditemukan
                  </p>
                  <p className="text-sm text-neutral-500 max-w-sm mx-auto">
                    Tidak ada program yang cocok dengan kata kunci &ldquo;{searchQuery}&rdquo; pada
                    kategori ini.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setActiveCategory('all');
                    }}
                    className="inline-flex items-center justify-center min-h-[44px] px-5 py-2.5 text-sm font-medium rounded-xl bg-neutral-950 text-white hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    Tampilkan Semua Kelas
                  </button>
                </div>
              )}

              <div aria-live="polite" className="sr-only">
                {copiedId ? 'Tautan kelas berhasil disalin ke clipboard.' : ''}
                {bioCopied ? 'Tautan bio berhasil disalin ke clipboard.' : ''}
              </div>
            </section>
          </div>
        </main>

        <footer className="border-t border-neutral-200/80 bg-[#f7f7f5]">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-neutral-500">
            <p>© {new Date().getFullYear()} Ekosistem Kelas Jago. Seluruh tautan resmi.</p>
            <a
              href="#top"
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Kembali ke atas
            </a>
          </div>
        </footer>
      </div>
    </MotionConfig>
  );
}
